/*
 * Simple web client
 */

#include <stdio.h>
#include <string.h>
#include "webclient.h"
#include "csapp.h"

#define LINEBUF_SIZE 4096

int main(int argc, char **argv) {
	if (argc != 3) {
		fatal("Usage: webclient <url> <output file>");
	}

	char *url = xstrdup(argv[1]);
	const char *output_filename = argv[2];

	/* parse URL */
	if (!strncpy(url, "http://", 7) != 0) {
		fatal("only http URLs are supported");
	}
	url += 7;
	char *host, *resource;
	host = url;
	resource = strchr(host, '/');
	if (!resource) {
		fatal("Invalid URL");
	}
	*resource = '\0';
	resource++;

	/* see if a port was specified */
	const char *port = "80"; /* default HTTP port */
	char *p = strchr(host, ':');
	if (p) {
		*p = '\0';
		port = p+1;
	}

	printf("host: %s\nport: %s\nresource: /%s\n", host, port, resource);

	/* Connect to server */
	int connfd = Open_clientfd((char *)host, (char *)port);

	/* Send request */
	writestr(connfd, "GET /");
	writestr(connfd, resource);
	writestr(connfd, " HTTP/1.1\r\n");
	writestr(connfd, "Host: ");
	writestr(connfd, host);
	writestr(connfd, "\r\nUser-Agent: jhucsf/0.1\r\n");
	writestr(connfd, "Accept: */*\r\n\r\n");

	rio_t in;
	rio_readinitb(&in, connfd);

	/* Read response */
	char linebuf[LINEBUF_SIZE];
	Rio_readlineb(&in, linebuf, LINEBUF_SIZE);
	printf("First line: %s\n", linebuf);

	/* make sure response code was 200 */
	char *p2 = strchr(linebuf, ' ');
	if (!p2) { fatal("bad HTTP response?"); }
	p2++;
	if (strncmp(p2, "200", 3) != 0) { fatal("HTTP response not 200"); }

	/* Read headers (detect chunked encoding) */
	int done_with_headers = 0;
	int chunked = 0;
	int content_length = 0;
	while (!done_with_headers) {
		readline(&in, linebuf, LINEBUF_SIZE);
		if (strcmp(linebuf, "") == 0) {
			done_with_headers = 1;
		} else {
			printf("Header: %s\n", linebuf);
			if (strcmp(linebuf, "Transfer-Encoding: chunked") == 0) {
				printf("Chunked encoding\n");
				chunked = 1;
			} else if (strncmp(linebuf, "Content-Length: ", 16) == 0) {
				content_length = atoi(linebuf + 17);
				printf("Content-Length is %d\n", content_length);
			}
		}
	}

	/* Read message body, save to output file */
	int outfd = Open(output_filename, O_WRONLY|O_CREAT, DEF_MODE);

	if (chunked) {
		/* chunked encoding */
		while (1) {
			/* determine size of next chunk */
			readline(&in, linebuf, LINEBUF_SIZE);
			unsigned chunk_len;
			sscanf(linebuf, "%x", &chunk_len);

			/* if chunk size is 0, body has ended */
			if (chunk_len == 0) { break; }

			/* read chunk, write to output file */
			char *buf = xmalloc(chunk_len);
			rio_readnb(&in, buf, chunk_len);
			rio_writen(outfd, buf, chunk_len);
			free(buf);

			/* need to read another \r\n following the chunk */
			Rio_readnb(&in, linebuf, 2);
		}
	} else {
		printf("Only chunked encoding is supported :-(\n");
	}

	/* Close file descriptors */
	close(outfd);
	close(connfd);

	/* Success? */
	printf("Download successful?\n");

	return 0;
}
