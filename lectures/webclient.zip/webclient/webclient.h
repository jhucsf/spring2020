/*
 * Simple web client
 */

#ifndef WEBCLIENT_H
#define WEBCLIENT_H

#include <stddef.h>
#include <sys/types.h>
#include "csapp.h"

/* general helper functions */
void fatal(const char *msg);
void *xmalloc(size_t nbytes);
char *xstrdup(const char *s);
ssize_t readline(rio_t *in, char *usrbuf, size_t maxlen);
void writestr(int outfd, const char *s);
void copyto(int fromfd, int tofd);

#endif /* WEBCLIENT_H */
