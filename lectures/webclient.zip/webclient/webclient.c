/*
 * Simple web client
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "csapp.h"
#include "webclient.h"

/*
 * Called to indicate a fatal error.
 * Prints an error message to stderr and exits the program.
 */
void fatal(const char *msg) {
	fprintf(stderr, "error: %s\n", msg);
	exit(1);
}

/*
 * Allocate memory, calling fatal if the allocation fails.
 */
void *xmalloc(size_t nbytes) {
	void *p = malloc(nbytes);
	if (!p) {
		fatal("malloc failed");
	}
	return p;
}

/*
 * Duplicate a string, calling fatal if the allocation fails.
 */
char *xstrdup(const char *s) {
	size_t len = strlen(s);
	char *dup = xmalloc(len + 1);
	strcpy(dup, s);
	return dup;
}

/*
 * Convenience function to read a line and trim trailing
 * CR or CRLF.
 */
ssize_t readline(rio_t *in, char *usrbuf, size_t maxlen) {
	ssize_t len = rio_readlineb(in, usrbuf, maxlen);
	if (len > 0 && usrbuf[len-1] == '\n') {
		/* trim trailing LF (newline) */
		usrbuf[len-1] = '\0';
		len--;
	}
	if (len > 0 && usrbuf[len-1] == '\r') {
		/* trim trailing CR */
		usrbuf[len-1] = '\0';
		len--;
	}
	return len;
}

/*
 * Write a string to a file descriptor.
 */
void writestr(int outfd, const char *s) {
	size_t len = strlen(s);
	rio_writen(outfd, (char*)s, len);
}

/*
 * Copy as many bytes as possible from fromfd to tofd.
 */
void copyto(int fromfd, int tofd) {
	char *buf = xmalloc(4096);
	int done = 0;
	while (!done) {
		ssize_t n;
		n = rio_readn(fromfd, buf, 4096);
		if (n <= 0) {
			done = 1;
		} else {
			n = rio_writen(tofd, buf, n);
			if (n < 0) {
				done = 1;
			}
		}
	}
	free(buf);
}
