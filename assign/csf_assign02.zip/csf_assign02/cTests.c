/*
 * Unit tests for C version of postfix calculator
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tctest.h"
#include "cPostfixCalc.h"

typedef struct {
	/* TODO: add fields for test fixture */
} TestObjs;

TestObjs *setup(void) {
	TestObjs *objs = malloc(sizeof(TestObjs));

	/* TODO: initialize test fixture fields */

	return objs;
}

void cleanup(TestObjs *objs) {
	/* TODO: do any cleanup needed for test fixture */

	free(objs);
}

/*
 * Prototypes for test functions
 */
void testAddPositive(TestObjs *obj);         /* example test function */
void testAddPositiveInvalid(TestObjs *obj);  /* example test function */
/* TODO: add prototypes for your test functions */

/* set to nonzero if a call to exit is expected */
int expectedExit;
/* jump buffer that our version of exit can use to jump back to test function */
sigjmp_buf exitBuf;

/*
 * Custom version of exit: useful for testing functions where
 * the expected behavior is a call to exit (e.g., because
 * an argument value is invalid.)  If the expectedExit
 * variable is set to a nonzero value, uses siglongjmp (via
 * exitBuf) to return control to the test function.
 * If expectedExit is not set, immediately fails the
 * current test.
 */
void exit(int exitCode) {
	if (expectedExit) {
		/* jump back to test function */
		siglongjmp(exitBuf, 1);
	} else {
		/* exit called unexpectedly, fail the test */
		FAIL("Unexpected exit");
	}
}

int main(void) {
	TEST_INIT();

	TEST(testAddPositive);
	TEST(testAddPositiveInvalid);
	/* TODO: use the TEST macro to execute each of your test functions */

	TEST_FINI();
}

/*
 * Example test function.
 */
void testAddPositive(TestObjs *obj) {
	ASSERT(2L == addPositive(1L, 1L));
	ASSERT(23L == addPositive(15L, 8L));
}

/*
 * Example of a test function that verifies that an invalid
 * input results in a call to the exit function.
 */
void testAddPositiveInvalid(TestObjs *obj) {
	/*
	 * addPositive should call exit if either of its arguments is negative
	 */

	expectedExit = 1;

	if (sigsetjmp(exitBuf, 1) == 0) {
		addPositive(-1L, 1L);
		FAIL("addPositive with invalid first argument did not exit");
	} else {
		printf("addPositive exited, good...");
	}

	if (sigsetjmp(exitBuf, 1) == 0) {
		addPositive(1L, -1L);
		FAIL("addPositive with invalid second argument did not exit");
	} else {
		printf("addPositive exited, good...");
	}
}

/* TODO: add your test functions */
