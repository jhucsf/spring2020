/*
 * C postfix calculator
 * function implementation
 */

#include <stdio.h>
#include <stdlib.h>
#include "cPostfixCalc.h"

/*
 * Example function (see tests in cTests.c)
 */
long addPositive(long a, long b) {
	if (a < 0L || b < 0L) {
		printf("Error: values must be positive\n");
		exit(1);
	}
	return a + b;
}

/* TODO: add function implementations */
