/*
 * C postfix calculator
 * main function
 */

#include <stdio.h>
#include <stdlib.h>
#include "cPostfixCalc.h"

int main(int argc, char **argv) {
	if (argc != 2) {
		printf("Wrong number of arguments\n");
		return 1;
	}

	/* TODO: implement for real */
	printf("argv[1] is %s\n", argv[1]);

	return 0;
}
