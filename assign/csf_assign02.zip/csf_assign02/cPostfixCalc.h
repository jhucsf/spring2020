/*
 * Common header file for C version of postfix calculator
 */

#ifndef CPOSTFIXCALC_H
#define CPOSTFIXCALC_H

/* TODO: add #defines for constants used by your functions */

long addPositive(long a, long b); /* example function */
/* TODO: Add prototypes for your postfix calculator functions */

#endif /* CPOSTFIXCALC_H */
